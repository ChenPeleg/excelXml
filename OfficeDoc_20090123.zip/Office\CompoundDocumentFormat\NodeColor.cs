using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Office.CompoundDocumentFormat
{
    public static class NodeColor
    {
        public const byte Red = 0;
        public const byte Black = 1;
    }
}
