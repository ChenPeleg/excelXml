using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Office.Excel
{
    public class PropertyIDs
    {
        public const UInt16 BlipId = 260;
    }
}
