﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace QiHe.Office.Excel
{
	public partial class MSOCONTAINER : Record
	{
		public MSOCONTAINER() { }

		public MSOCONTAINER(Record record) : base(record) { }

	}
}
